#include <stdio.h>
#include <string.h>
#include "Question1/Factorial.h"
#include "Question2/Fibonacci.h"
#include "Question3/GCM.h"
#include "Question4/Conversion.h"
#include "Question5/validate.h"
#include "Question6/Math_function.h"


int main() {
    int choice;
    int n;
    while (1) {
        printf("\n=== Menu ===\n");
        printf("1. Exercise 1: Factorial\n");
        printf("2. Exercise 2: Fibonacci\n");
        printf("3. Exercise 3: GCD\n");
        printf("4. Exercise 4: Conversion\n");
        printf("5. Exercise 5: String validation\n");
        printf("6. Exercise 6: Math functions\n");
        printf("0. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("\nExercise 1: Factorial Calculation\n");
                printf("Enter a number: ");
                scanf("%d", &n);

                printf("Factorial of %d (Iterative): %ld\n", n, fact(n));
                printf("Factorial of %d (Recursive): %ld\n", n, rfact(n));
            break;
            case 2:
                printf("Enter a number: ");
                scanf("%d", &n);

                // Print Fibonacci numbers up to n using the recursive function
                printf("Recursive Fibonacci sequence up to F(%d): ", n);
                for (int i = 0; i < n; i++) {
                    printf("%ld ", recursive_fib(i));  // Call recursive function
                    }
                printf("\n");

                // Print Fibonacci numbers up to n using the iterative function
                printf("Iterative Fibonacci sequence up to F(%d): ", n);
                for (int i = 0; i < n; i++) {
                    printf("%ld ", iterative_fib(i));  // Call iterative function
                }
                printf("\n");
            break;
            case 3:
                int x = 0, y = 0;

                // User input
                printf("Enter the value of x\n");
                scanf("%d", &x);
                printf("Enter the value of y\n");
                scanf("%d", &y);

                // Ensure x >= y by swapping if necessary
                if (y > x) {
                    int temp = x;
                    x = y;
                    y = temp;
                }

                // Print GCD using the iterative method
                printf("The GCD (iteration) is: %d\n", GCM_iterative(x, y));

                // Print GCD using the recursive method
                printf("The GCD (recursion) is: %d\n", GCM_recursive(x, y, y - 1));
            break;
            case 4:
                int hexa;
                char word[20];

                // Input number for hexadecimal conversion
                printf("Enter a number to turn into hex: ");
                scanf("%d", &hexa);

                printf("The Hexadecimal representation of %d is: ", hexa);
                printHex(hexa); // Use printHex to handle the case for 0 properly
                printf("\n");

                // Input word to reverse
                printf("Enter a word to reverse: ");
                scanf("%s", word);

                // Output the reversed word
                Reverse(word, 0, strlen(word) - 1);
                printf("\nReversed word: %s\n", word);
            break;
            case 5:
                // Clear the input buffer after scanf
                while (getchar() != '\n');
                char input[100];  // Buffer for user input
                // Prompt the user to enter a string
                printf("Please enter a string:\n");
                if (fgets(input, sizeof(input), stdin)) {
                    // Remove trailing newline if present
                    size_t len = strlen(input);
                    if (len > 0 && input[len - 1] == '\n') {
                        input[len - 1] = '\0';  // Remove newline character
                    }
                    // Call the validateString function
                    validateString(input);
                } else {
                    printf("Error reading input.\n");
                }
            break;
            case 6:
                double num;
            printf("Enter a number to analyse: ");

            // Use %lf for double input
            if (scanf("%lf", &num) != 1) {
                printf("Invalid input. Please enter a valid number.\n");
                // Clear the input buffer
                while (getchar() != '\n');
                break;  // Skip to the next iteration of the loop
            }

            // Calculate and print ceil value
            printf("Ceil of %.2f: %.2f\n", num, calculateCeil(num));

            // Calculate and print floor value
            printf("Floor of %.2f: %.2f\n", num, calculateFloor(num));

            // Calculate and print rounded value
            printf("Rounded value of %.2f: %d\n", num, roundValue(num));
            break;
            case 0:
                printf("Exiting...\n");
            return 0;
            default:
                printf("Invalid choice. Try again.\n");
        }
    }
    return 0;
}
