// validate.h
#ifndef VALIDATE_H
#define VALIDATE_H

// Function to validate the string and calculate various properties
void validateString(const char *inp);

#endif // VALIDATE_H
