#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "validate.h"

void validateString(const char *inp) {
    int counter = 0;         // Number of characters in the string
    int freq[256] = {0};     // Frequency array for all ASCII characters
    const char *temp = inp;  // Temporary pointer to traverse the string

    // Validate the string and calculate its length, while ignoring spaces
    while (*temp) {
        if (isdigit(*temp)) {
            printf("Not a valid string\n");
            return;
        }
        freq[(unsigned char)*temp]++;  // Increment frequency for each character
        temp++;
        counter++;
    }

    // Find the most repeated character
    int maxFreq = 0;
    char mostRepeatedChar = '\0';
    for (int i = 0; i < 256; i++) {
        if (freq[i] > maxFreq) {
            maxFreq = freq[i];
            mostRepeatedChar = (char)i;
        }
    }

    // Display results
    printf("Valid string\n");
    printf("The size of the string is %d\n", counter);
    printf("The first character in the string is '%c'\n", inp[0]);
    if (mostRepeatedChar != '\0') {
        printf("The most repeated character is '%c' with a frequency of %d\n", mostRepeatedChar, maxFreq);
    }
}
