#ifndef GCM_H
#define GCM_H

// Recursive GCD declaration
int GCM_recursive(int x, int y, int r);

// Iterative GCD declaration
int GCM_iterative(int x, int y);

#endif
