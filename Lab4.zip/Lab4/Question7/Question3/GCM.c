#include "GCM.h"

// Recursive GCD function
int GCM_recursive(int x, int y, int r) {
    if (x % r == 0 && y % r == 0) {
        return r;  // Base case: found common divisor
    }
    return GCM_recursive(x, y, r - 1);  // Recursive call with smaller r
}

// Iterative GCD function
int GCM_iterative(int x, int y) {
    for (int i = y; i >= 1; i--) {
        if (x % i == 0 && y % i == 0) {
            return i;  // Found GCD
        }
    }
    return 1;  // GCD is 1 if no other divisor is found
}
