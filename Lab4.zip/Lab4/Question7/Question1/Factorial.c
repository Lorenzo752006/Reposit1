#include "Factorial.h"

// Iterative function to calculate factorial
long fact(int n) {
    long ans = 1; // Initialize ans to 1
    for (; n > 1; n--) {
        ans *= n;
    }
    return ans;
}//The stack is only called once to store the variables ans and n making it very memory efficient

// Recursive function to calculate factorial
long rfact(int n) {
    if (n > 0) {
        return n * rfact(n - 1); // Recursive call
    } else {
        return 1; // Base case
    }
}