#ifndef FACTORIAL_H
#define FACTORIAL_H

// Declare the functions implemented in factorial.c
long fact(int n);    // Iterative factorial
long rfact(int n);   // Recursive factorial

#endif
