// Conversion.h
#ifndef CONVERSION_H
#define CONVERSION_H

// Function to convert decimal to hexadecimal
void DecToHex(int n);

// Function to reverse a string
void Reverse(char str[], int start, int end);

// Helper function for hexadecimal conversion (to handle 0 correctly)
void printHex(int n);

#endif
