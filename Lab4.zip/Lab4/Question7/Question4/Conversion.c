// Conversion.c
#include <stdio.h>
#include "Conversion.h" // Include the header to connect function declarations with definitions

void DecToHex(int n) {
    // Base case: handle zero explicitly
    if (n == 0) {
        return;
    }

    // Recursive case: first divide the number by 16
    DecToHex(n / 16);

    // Now print the current digit (most significant digit is printed last)
    int r = n % 16;
    if (r < 10) {
        printf("%d", r);  // For 0-9, print the number
    } else {
        printf("%c", 'A' + (r - 10));  // For 10-15, print A-F
    }
}

void printHex(int n) {
    if (n == 0) {
        printf("0");  // Special case for zero
    } else {
        DecToHex(n);  // Call the recursive function for non-zero values
    }
}

void Reverse(char str[], int start, int end) {
    if (start >= end) {
        return;
    }
    char temp = str[start];
    str[start] = str[end];
    str[end] = temp;
    Reverse(str, start + 1, end - 1);
}
