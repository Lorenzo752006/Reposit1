#include <stdio.h>
#include <math.h>
#include "Math_function.h"

// Function to calculate the ceiling value
double calculateCeil(double x) {
    return ceil(x);
}

// Function to calculate the floor value
double calculateFloor(double x) {
    return floor(x);
}

// Function to round a value based on the fractional part
int roundValue(double x) {
    if (x - (int)x < 0.5) {
        return (int)x; // Round down
    } else {
        return (int)x + 1; // Round up
    }
}
