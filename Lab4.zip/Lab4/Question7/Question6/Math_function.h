#ifndef MATH_FUNCTIONS_H
#define MATH_FUNCTIONS_H

// Function to calculate the ceiling value
double calculateCeil(double x);

// Function to calculate the floor value
double calculateFloor(double x);

// Function to round a value based on the fractional part
int roundValue(double x);

#endif // MATH_FUNCTIONS_H
