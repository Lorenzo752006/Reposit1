#include <stdio.h>
#include "Fibonacci.h"  // Include the header file

// Recursive Fibonacci function
long recursive_fib(int n) {
    if (n == 0) return 0;  // Base case: F(0) = 0
    if (n == 1) return 1;  // Base case: F(1) = 1
    return recursive_fib(n - 1) + recursive_fib(n - 2);  // Recursive step
}

// Iterative Fibonacci function
long iterative_fib(int n) {
    if (n == 0) return 0;  // Base case: F(0) = 0
    if (n == 1) return 1;  // Base case: F(1) = 1

    long a = 0, b = 1, c;
    for (int i = 2; i <= n; i++) {
        c = a + b;  // Calculate next Fibonacci number
        a = b;
        b = c;
    }
    return b;  // Return the nth Fibonacci number
}
