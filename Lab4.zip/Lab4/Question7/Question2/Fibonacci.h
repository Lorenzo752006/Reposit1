#ifndef FIBONACCI_H
#define FIBONACCI_H

// Function declarations
long recursive_fib(int n);   // Recursive Fibonacci function
long iterative_fib(int n);   // Iterative Fibonacci function

#endif // FIBONACCI_H
