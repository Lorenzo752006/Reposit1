#include <stdio.h>
#include <string.h>

void DecToHex(int n) {
    if (n == 0) {
        return;
    }
    DecToHex(n / 16);
    int r = n % 16;
    if (r < 10) {
        printf("%d",r);
    }
    if (r == 10) {
        printf("%c",'A');
    }
    if (r == 11) {
        printf("%c",'B');
    }
    if (r == 12) {
        printf("%c",'C');
    }
    if (r == 13) {
        printf("%c",'D');
    }
    if (r == 14) {
        printf("%c",'E');
    }
    if (r == 15) {
        printf("%c",'F');
    }
}

void Reverse(char str[], int start, int end) {
    if (start >= end) {
        return;
    }
    char temp = str[start];
    str[start] = str[end];
    str[end] = temp;
    Reverse(str, start + 1, end - 1);
}

int main(void) {
    int hexa;
    char word[20];
    printf("Enter a number to turn into hexa\n");
    scanf("%d", &hexa);

    printf("Enter a word to reverse\n");
    scanf("%s", &word);

    printf("The Hexa representation of %d is: ", hexa);
    DecToHex(hexa);

    Reverse(word, 0, strlen(word)-1);
    printf("\nReversed word: %s", word);
    return 0;
}
