#include <stdio.h>

int Fibonacci(int n) {
    if (n == 0 || n == 1) {
        return n;
    }
    return Fibonacci(n-1)+Fibonacci(n-2);
}

int main(void) {
    int num;
    int first = 0;
    int second = 1, next;
    printf("Enter the amount of terms\n");
    scanf("%d", &num);

    printf("The Fibonacci sequence using iteration\n");
    for (int i = 0; i < num; i++) {
        if (i <= 1) {
            next = i;
        } else {
            next = first + second;
            first = second;
            second = next;
        }
        printf("%d ", next);
    }

    printf("\nThe Fibonacci sequence using recursion\n");
    for (int i = 0; i < num; i++) {
        printf("%d ", Fibonacci(i));
    }

    return 0;
}
