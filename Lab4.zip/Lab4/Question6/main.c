#include <stdio.h>
#include <math.h>
int main(void) {
    double x = 2.5;
    printf("%f\n", ceil(x));
    printf("%f\n", floor(x));

    if (x-(int)x < 0.5) {
        printf("%d\n", (int)x);
    }else {
        printf("%d\n", (int)x+1);
    }
    return 0;
}
