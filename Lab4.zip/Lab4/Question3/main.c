#include <stdio.h>

int GCM(int x, int y, int r) {
    if  (x % r == 0 && y % r == 0) {
        return r;
    }
    return GCM(x, y, (r-1));
}

int main(void) {
    int x = 0, y = 0;
    printf("Enter the value of x\n");
    scanf("%d", &x);
    printf("Enter the value of y\n");
    scanf("%d", &y);

    if (y > x) {
        int temp = 0;
        temp = x;
        x = y;
        y = temp;
    }

    for (int i = y; i >= 1; i--) {
        if (x % i == 0 && y % i == 0) {
            printf("The GCM (iteration) is: %d \n", i);
            break;
        }
    }

    printf("The GCM (recursion) is: %d\n", GCM(x, y, y-1));
    return 0;
}
