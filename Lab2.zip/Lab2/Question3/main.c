//Exercise 3
//Write a program that asks for three words and outputs each in reverse order.

#include <stdio.h>
#include <string.h>

int main(void) {
    printf("Enter 3 words\n");
    char word1[20];
    char word2[20];
    char word3[20];
    char temp[20];
    scanf("%s %s %s", word1, word2, word3);
    for (int i = 0; i < strlen(word1)/2; i++) {
        temp[i] = word1[i];
        word1[i] = word1[strlen(word1)-i-1];
        word1[strlen(word1)-i-1] = temp[i];
    }
    for (int i = 0; i < strlen(word2)/2; i++) {
        temp[i] = word2[i];
        word2[i] = word2[strlen(word2)-i-1];
        word2[strlen(word2)-i-1] = temp[i];
    }
    for (int i = 0; i < strlen(word3)/2; i++) {
        temp[i] = word3[i];
        word3[i] = word3[strlen(word3)-i-1];
        word3[strlen(word3)-i-1] = temp[i];
    }
    printf("%s, %s, %s\n", word1, word2, word3);
    return 0;
}
