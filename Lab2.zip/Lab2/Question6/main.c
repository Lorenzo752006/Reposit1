//Exercise 6
//Write a program that repeatedly converts dollars to euros for a sequence of 10 inputs.
//Make use of symbolic constants to render your program readable.
//1 dollar = 0.92 euros

#include <stdio.h>

int main(void) {
    const float dollar = 0.92;
    float amount = 0;
    for (int i=0; i<10; i++) {
        printf("Enter the amount of dollars $\n");
        scanf("%f", &amount);
        printf("The amount you entered is %.2f in euros\n", amount*dollar);
    }
    return 0;
}
