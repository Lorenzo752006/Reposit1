//Exercise 8
//Write a program that computes the Reimann zeta function, trying out different
//approximations of infinity:
//You may want to make use of functions declared in math.h

#include <math.h>
#include <stdio.h>

double zeta_function(int terms, double s) {
    double sum = 0.0;
    for (int n = 1; n <= terms; n++) {
        sum += 1.0 / pow(n, s);
    }
    return sum;
}

int main() {
    double s;
    int terms;

    printf("Enter the value of s (must be greater than 1): ");
    scanf("%lf", &s);
    printf("Enter the number of terms for approximation: ");
    scanf("%d", &terms);

    if (s <= 1) {
        printf("The value of s must be greater than 1 for the series to converge.\n");
        return 1;
    }

    double result = zeta_function(terms, s);

    printf("Approximation of the Riemann zeta function with %d terms for s = %lf: %lf\n", terms, s, result);

    return 0;
}
