#include <stdio.h>
//Exercise 1
//Write a program that accepts an integer as input and prints out the corresponding
//character from the system’s current character set

int main(void) {
    int num = 0;
    printf("Enter a number: ");
    scanf("%d", &num);
    char word = (char)num;
    printf("%d corresponds to character %c in ASCII code\n", num, word);
    return 0;
}


