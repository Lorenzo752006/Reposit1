//Exercise 7
//Write a program that computes n!(factorial), where n is supplied by the end user.

#include <stdio.h>

int factorial(int n) {
    if (n == 0) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}


int main(void) {
    int num;
    int counter;
    printf("Enter a number and find out its factorial!\n");
    scanf("%d", &num);
    num = factorial(num);
    printf("The factorial using recursion is %d\n", num);

    for (int i = 0; i < num; i++) {
        counter = num * (num-i);
    }
    printf("The factorial using iteration is %d\n", counter);
    return 0;
}
