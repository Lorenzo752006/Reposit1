//Exercise 5
//Write a program that converts a sequence of 10 user-supplied number of days
//into ‘weeks & days’. Make use of symbolic constants to render your program readable.

#include <cstdio>

int main() {
    const int week = 7;
    int days;
    int total;

    for (int i =0; i<10; i++) {
        printf("Enter a number of days\n");
        scanf("%d", &days);
        total += days;
    }

    days =0;

    if (total % week == 0) {
        total = total / week;
        printf("Total weeks: %d\n", total);
    }else{
        while (total % week != 0) {
            total--;
            days++;
        }
        total = total / week;
        printf("Total weeks: %d and total days:%d\n", total, days);
    }
    return 0;
}
