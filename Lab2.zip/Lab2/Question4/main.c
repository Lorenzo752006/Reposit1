#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct employee {
    char name[20];
    char surname[20];
    int age;
    float pay;
};

int main(void) {
    int decimal;
    struct employee employees[10];
    for (int i = 0; i < 11; i++) {
        if (i % 5 == 0 && i != 0) {
            for (int j = 0; j < 5; j++) {
                if (strlen(employees[j].name) > 11 && strlen(employees[j].surname) > 11) {
                    employees[i].name[11] = '\0';
                    employees[i].surname[11] = '\0';
                }
                printf("How many decimal places would you like the pay to display?");
                scanf("%d", &decimal);
                printf("Employee %d: Name = %s %s, Age = %d, Monthly Pay = %.2f, Yearly Pay = %.*f\n",(j+1), employees[j].name, employees[j].surname, employees[j].age, employees[j].pay, decimal, employees[i].pay*13);
            }
        }
        else {
            printf("Please enter Employee name, surname, age and (monthly) pay-cheque salary\n");
            scanf("%s%s%d%f", &employees[i].name, &employees[i].surname, &employees[i].age, &employees[i].pay);
        }
        float pay;
        for (int i = 0; i < 11; i++) {
            pay += employees[i].pay;
        }
        printf("The average monthly salary is $%.*f", decimal, pay/10);
    }
    return 0;
}

