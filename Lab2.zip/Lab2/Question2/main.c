//Exercise 2
//1. Note down the result
//2. Change the type of value to double. How does the result change?
//3. Modify the program to round-off the result to 4 decimal points.
//4.Change the type of value to int. What is the result displayed for %f and %d?
//Explain the reason why.
//5. What happens if the integer corresponds to an index for a non-printable character?
//6. Modify the program further to display the corresponding index as octal and
//hex formatted integers.

#include <stdio.h>
int main() {
    float weight;
    int value;
    printf("Enter your weight in pounds: \n");
    scanf("%f", &weight);
    // Platinum is $1770 / pound
    // 14.5 troy ounces in 1 pound
    value = 1770.0 * weight * 14.5;
    printf ("Your weight in platinum costs $%d. \n", value);
    printf("The corresponding index in octa is: %o. \n", value);
    printf("The corresponding index in hexa is: %x. \n", value);
    return 0;
}

//1. The result tells us how much our weight costs in platinum
//2. No difference is noted for the most part as only when higher degree of precision is required would we see a difference
//4.By using %f value will remain 0 as you need to match the correct identifier,
//  By using %d value will be less accurate as the decimal portion gets cut off
//5. An empty space gets left instead of a character