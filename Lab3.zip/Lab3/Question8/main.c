#include <stdio.h>
#include <string.h>
#include <ctype.h>

void PrintWord(int start, int end, char word[]) {
    for (int k = start; k <= end; k++) {
        printf("%c", word[k]);
    }
    printf("\n");
}

int main(void) {
    char text[200];
    int counter = 0;
    int hasHyphen = 0;
    int errors = 0;
    printf("Enter a text stream:\n");
    fgets(text, sizeof(text), stdin);

    for (int i = 0; i <= strlen(text); i++) {
        if (text[i] != ' ' && text[i] != '\n' && text[i] != '\0' && text[i] != '\t')  {//divide the text into words
            counter++;
        }else {

            if (i < strlen(text) - 1 && text[i] == ' ' && text[i + 1] == ' ') {//repeated space check and out of bounds check
                errors++;
                printf("Repeated spaces found at position %d\n", i);
                i++;  // Skip the next space to avoid counting it twice
            }

            if (i > 0 && ispunct(text[i - 1]) && text[i] == ' ') {//Space found following punctuation and out of bounds check
                errors++;
                printf("Space found following punctuation at position %d\n", i);
            }


            for (int k = i-(counter); k <= i-1; k++) {//non-alphabetical character start check
                if (!isalnum(text[k]) && k == i-counter) {
                    errors++;
                    printf("The character, %c, is non-alphabetical in the word ", text[k]);
                    PrintWord(i-counter, i, text);
                }
            }

            for (int k = i-counter; k <= i; k++) {//capital letter check
                if (isupper(text[k]) && k > i-counter) {
                    errors++;
                    printf("The letter, %c, is capital in the word ", text[k]);
                    PrintWord(i-counter, i, text);
                }
            }

            if (counter > 10) {//start of hyphen check
                for (int k = i-counter; k <= i; k++) {
                    if (text[k] == '-') {//if a hyphen is found no more need to check remaining characters
                        hasHyphen = 1;
                        break;
                    }
                }
                if (hasHyphen == 0) {//if after the whole word is scanned no hyphens are found than there aren't any
                    errors++;
                    printf("There are more than 10 characters which do not include an hyphen in the word ");
                    PrintWord(i-counter, i, text);
                }
            }
            counter = 0;//end of hyphen check
            hasHyphen = 0;
        }
    }


    printf("You entered: %s\n", text);
    if (errors > 0) {
        for (int i = 1; i < errors+1; i++) {
            printf("%d errors found\n", i);
        }
    } else {
        printf("No errors found\n");
    }
    return 0;
}

//Test data:
//*ham @cheese Cheese-burger cheese-burger Cheeseburger cheese-burger cheeseBurger -> 5 errors as expected
//Ham cheese cheese-burger -> No errors as expected
//Ham  cheese. burger, lettuce-mayo -> 3 errors as expected