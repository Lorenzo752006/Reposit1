#include <stdio.h>

int main(void) {
    int seq[20];
    int counter=0;
    int sum=0;
    int mode = seq[0];
    int maxCount = 1;
    int currentCount = 1;

    do {
        printf("Please enter a number or 0 to exit\n");
        scanf("%d", &seq[counter]);
        if (seq[counter] == 0) {
            break;
        }
        counter++;
    }while(counter < 20 && seq[counter - 1] != 0);

    for (int i = 0; i < counter; i++) {//sorts the list
        for (int j = 0; j < counter - i - 1; j++) {
            if (seq[j] > seq[j + 1]) {
                int temp = seq[j];
                seq[j] = seq[j + 1];
                seq[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < counter; i++) {//sum calculation
        sum+=seq[i];
    }
    printf("The mean is: %d\n", (sum/counter));//mean print

    for (int i = 1; i < counter; i++) {//mode calculation
        if (seq[i] == seq[i - 1]) {//since it is sorted same numbers will be nect to each other
            currentCount++;
        } else {
            if (currentCount > maxCount) {//if a new number is found next and the count of it is larger than the previous one
                maxCount = currentCount;
                mode = seq[i - 1];
            }
            currentCount = 1;
        }
    }
    if (currentCount > maxCount) {//checks the last element
        mode = seq[counter - 1];
    }
    printf("The mode is: %d\n", mode);
    printf("The median is: %d\n", seq[(counter+1)/2]);
    return 0;
}
