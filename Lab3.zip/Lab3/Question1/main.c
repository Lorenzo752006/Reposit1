#include <stdio.h>

int main(void)
{
    long num = 0;
    long sum = 0L; /* initialize sum to zero */
    int status;

    do
    {
        sum = sum + num;
        printf("Please enter next integer (q to quit): ");
        status = scanf("%ld", &num);

    }while (status == 1);
    printf("Those integers sum to %ld.\n", sum);

    return 0;
}
