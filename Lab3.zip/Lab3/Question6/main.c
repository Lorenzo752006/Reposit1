#include <stdio.h>
#include <string.h>

int main(void) {
    float salary = 0;
    float gross = 0;
    float tax = 0;
    char ans[4];

    printf("Please enter your salary $");
    scanf("%f", &salary);
    gross = salary;

    printf("Do you collect old electronic equipment for green disposal? - ");
    scanf("%s", &ans);

    if (strcmp(ans, "YES") == 0 || strcmp(ans, "Yes") == 0 || strcmp(ans, "yes") == 0 && salary > 10000.00) {
        tax = 10000.00f * 0.15f;
        gross = gross - tax;
    }else if (strcmp(ans, "NO") == 0 || strcmp(ans, "No") == 0 || strcmp(ans, "no") == 0 && salary > 10000.00){
       tax = 10000.00f * 0.18f;
        gross = gross - tax;
    }

    if (gross > 8000.00) {
        tax = tax + 8000.00f * 0.20f;
        gross = gross - 8000.00f;
        tax = tax + gross * 0.25f;
    }

    salary = salary - tax;
    printf("Your salary is $%.2f\n", salary);

    printf("Are you apart of the ICT Industry? - ");
    scanf("%s", &ans);
    if(strcmp(ans, "YES") == 0 || strcmp(ans, "Yes") == 0 || strcmp(ans, "yes") == 0) {
        salary = salary * 1.05f;
        printf("You are entitled to a rebate of 5%%, your salary is now $%.2f\n", salary);
    }else {
        printf("Your salary is still $%.2f\n", salary);
    }


    return 0;
}
