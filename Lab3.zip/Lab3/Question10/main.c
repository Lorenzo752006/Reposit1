#include <stdio.h>
#include <string.h>

float CalculateTotal(const int bill[], int counter) {
    float total = 0.0f;
    for (int i = 0; i < counter; i++) {
        if (bill[i] == 1) {
            total += 1.99f;
        } else if (bill[i] == 2) {
            total += 800.00f;
        } else if (bill[i] == 3) {
            total += 65.99f;
        }
    }
    return total;
}

int main(void) {
    char opt, pick;
    int amount, counter = 0;
    int bill[50];

    do {
        printf("1. Add items to shopping cart\n2. Show current total\n3. Check out\n4. Cancel session\nq. Quit\n");
        scanf("%c", &opt);
        getchar();

        switch (opt) {
            case '1':
                printf("Add items to shopping cart\n01 - candy - $1.99\n02 - computer - $800.00\n03 - video games - $65.99\n");
                scanf("%c", &pick);
                getchar();

                switch (pick) {
                    case '1':
                        printf("How many would you like?\n");
                        scanf("%d", &amount);
                        getchar();
                        for (int i = 0; i < amount; i++) {
                            bill[counter + i] = 1;
                        }
                        counter += amount;
                        break;
                    case '2':
                        printf("How many would you like?\n");
                        scanf("%d", &amount);
                        getchar();
                        for (int i = 0; i < amount; i++) {
                            bill[counter + i] = 2;
                        }
                        counter += amount;
                        break;
                    case '3':
                        printf("How many would you like?\n");
                        scanf("%d", &amount);
                        getchar();
                        for (int i = 0; i < amount; i++) {
                            bill[counter + i] = 3;
                        }
                        counter += amount;
                        break;
                    default:
                        printf("Invalid option, please try again\n");
                        break;
                }
                break;
            case '2':
                printf("Your total is $%.2f\n", CalculateTotal(bill, counter));
                break;
            case '3':
                printf("Are you sure you want to check out? Y or N\n");
                scanf("%c", &pick);
                getchar();
                if (pick == 'Y' || pick == 'y') {
                    printf("Here is your receipt\n");
                    for (int i = 0; i < counter; i++) {
                        if (bill[i] == 1) {
                            printf("Candy : $%.2f\n", 1.99f);
                        }else if (bill[i] == 2) {
                            printf("Computer : $%.2f\n", 800.00f);
                        }else if (bill[i] == 3) {
                            printf("Video : $%.2f\n", 65.99f);
                        }
                    }
                    printf("Thanks for shopping with us, your total is $%.2f\n", CalculateTotal(bill, counter));
                    printf("A new session will begin now\n");
                    memset(bill, 0, counter * sizeof(int));
                    amount = 0;
                    counter = 0;
                } else if (pick == 'N' || pick == 'n') {
                    break;
                }
                break;
            case '4':
                printf("Are you sure you want to start a new session? Y or N\n");
                scanf("%c", &pick);
                getchar();
                if (pick == 'Y' || pick == 'y') {
                    printf("A new session will begin now\n");
                    memset(bill, 0, counter * sizeof(int));
                    amount = 0;
                    counter = 0;
                } else if (pick == 'N' || pick == 'n') {
                    break;
                }
                break;
            case 'q':
                printf("Are you sure you want to exit? Y or N\n");
                scanf("%c", &pick);
                getchar();
                if (pick == 'Y' || pick == 'y') {
                    opt = 'q';
                } else if (pick == 'N' || pick == 'n') {
                    break;
                }
                break;
            default:
                printf("Invalid option: please try again\n");
                break;
        }
    } while (opt != 'q');
    return 0;
}