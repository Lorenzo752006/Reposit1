#include <iostream>

int main() {
    int num;
    int fact = 1;
    printf("Enter a number for its factorial\n");
    scanf("%d", &num);

    for (int i = 1; i <= num; i++) {
        fact = fact * i;
        printf("%d\n", fact);
    }
    printf("The factorial of %d is %d\n", num, fact);
    return 0;
}
