#include <stdio.h>
#include <string.h>
#include <time.h>

void timer(int seconds) {
    clock_t start_time = clock();
    clock_t end_time = seconds * CLOCKS_PER_SEC;34
    while (clock() - start_time < end_time) {
    }
    printf("You may try again\n");
}

int main(void) {
    const char pass[5] = "1234";
    char guess[5];
    int counter;
    do {
        counter++;
        if (counter % 5 == 0) {
            printf("You have been timed out for 10 seconds\n");
            timer(10);
        }else
        {
            printf("Please enter your 4 digit password:\n");
            scanf("%s", guess);
        }
    }while(strcmp(guess, pass) != 0);

    printf("Access granted\n");
    return 0;
}
