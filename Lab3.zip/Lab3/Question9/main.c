#include <ctype.h>
#include <stdio.h>

int main(void) {
    int nums[200];
    int count = 0;
    FILE *file = fopen("C:/Users/iabic/OneDrive/Desktop/Neville Grech/Programming principles/Lab3/Question9/file.txt", "w");

    if (file == NULL) {
        printf("Failed to create or open the file.\n");
        return 1;  // Exit the program if file creation failed
    }

    printf("Input a stream of real numbers between 1-100\nIn order to quit enter any letter");
    while (count < 200 && scanf("%d", &nums[count]) == 1) {
        if (nums[count] >= 1 && nums[count] <= 100) {
            fprintf(file, "%d ", nums[count]);
            count++;
        } else {
            printf("%d is out of range and will not be stored.\n", nums[count]);
        }
    }

    fclose(file);
    printf("Numbers within range have been stored in 'output.txt'.\n");

    return 0;
}

//24 46 3 57 2 67 58 43 120

