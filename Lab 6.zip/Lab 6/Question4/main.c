#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char title[40];
    char author[40];
    float price;
    long offset;
} Book;

typedef struct {
    long offset;
} IndexEntry;

void create_and_save_indexes(FILE *fp, const char *index_file) {
    FILE *index_fp = fopen(index_file, "wb");
    if (!index_fp) {
        perror("Unable to open index file");
        return;
    }

    long offset = 0;
    Book book;
    while (fread(&book, sizeof(Book), 1, fp)) {
        IndexEntry entry = {offset};
        fwrite(&entry, sizeof(IndexEntry), 1, index_fp);
        offset += sizeof(Book);
    }

    fclose(index_fp);
}

void load_indexes(FILE *fp, const char *index_file, IndexEntry *index, int *count) {
    FILE *index_fp = fopen(index_file, "rb");
    if (!index_fp) {
        perror("Unable to open index file");
        return;
    }

    *count = 0;
    while (fread(&index[*count], sizeof(IndexEntry), 1, index_fp)) {
        (*count)++;
    }

    fclose(index_fp);
}

void display_books(FILE *fp, IndexEntry *index, int count, int order) {
    printf("\nBooks:\n");
    for (int i = 0; i < count; i++) {
        int idx = order ? count - 1 - i : i;
        fseek(fp, index[idx].offset, SEEK_SET);
        Book book;
        fread(&book, sizeof(Book), 1, fp);
        printf("Title: %s, Author: %s, Price: $%.2f\n", book.title, book.author, book.price);
    }
}

int main() {
    const char *index_file = "book.idx";
    FILE *fp = fopen("book.dat", "rb");
    if (!fp) {
        perror("Unable to open file");
        return 1;
    }

    IndexEntry index[100];
    int count = 0;

    // Generate index if not exists
    FILE *index_fp = fopen(index_file, "rb");
    if (!index_fp) {
        fclose(fp);
        fp = fopen("book.dat", "rb");
        create_and_save_indexes(fp, index_file);
    } else {
        fclose(index_fp);
    }

    load_indexes(fp, index_file, index, &count);
    display_books(fp, index, count, 0); // Ascending
    display_books(fp, index, count, 1); // Descending

    fclose(fp);
    return 0;
}
