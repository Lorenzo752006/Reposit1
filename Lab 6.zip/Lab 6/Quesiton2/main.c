#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void search_replace_large(char *filename, char *search, char *replace) {
    FILE *file = fopen(filename, "r");
    FILE *temp = fopen("temp.txt", "w");

    if (!file || !temp) {
        perror("Error opening file");
        return;
    }

    char word[100], ch;
    int i = 0, search_len = strlen(search);

    while ((ch = fgetc(file)) != EOF) {
        if (isalnum(ch)) {
            word[i++] = ch;
        } else {
            word[i] = '\0';
            if (i > 0 && strcmp(word, search) == 0) {
                fputs(replace, temp);
            } else {
                fputs(word, temp);
            }
            fputc(ch, temp);
            i = 0;
        }
    }

    fclose(file);
    fclose(temp);

    remove(filename);
    rename("temp.txt", filename);
    printf("Replacement completed.\n");
}

int main() {
    char filename[100], search[50], replace[50];

    printf("Enter filename: ");
    scanf("%s", filename);
    printf("Enter word to search: ");
    scanf("%s", search);
    printf("Enter replacement word: ");
    scanf("%s", replace);

    search_replace_large(filename, search, replace);
    return 0;
}
