#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_FILE_SIZE 1000000  // 1MB file limit

void search_replace(char *filename, char *search, char *replace) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return;
    }

    // Load entire file into memory
    char *buffer = malloc(MAX_FILE_SIZE);
    if (!buffer) {
        perror("Memory allocation failed");
        fclose(file);
        return;
    }

    size_t len = fread(buffer, 1, MAX_FILE_SIZE, file);
    buffer[len] = '\0';
    fclose(file);

    // Replace whole words
    char *pos, temp[MAX_FILE_SIZE];
    char *start = buffer;
    size_t search_len = strlen(search), replace_len = strlen(replace);

    temp[0] = '\0';
    while ((pos = strstr(start, search))) {
        if ((pos == buffer || !isalnum(*(pos - 1))) && !isalnum(*(pos + search_len))) {
            strncat(temp, start, pos - start);
            strcat(temp, replace);
            start = pos + search_len;
        } else {
            strncat(temp, start, pos - start + search_len);
            start = pos + search_len;
        }
    }
    strcat(temp, start);

    // Write updated content back to file
    file = fopen(filename, "w");
    if (!file) {
        perror("Error opening file for writing");
        free(buffer);
        return;
    }
    fwrite(temp, 1, strlen(temp), file);
    fclose(file);

    free(buffer);
    printf("Replacement completed.\n");
}

int main() {
    char filename[100], search[50], replace[50];

    printf("Enter filename: ");
    scanf("%s", filename);
    printf("Enter word to search: ");
    scanf("%s", search);
    printf("Enter replacement word: ");
    scanf("%s", replace);

    search_replace(filename, search, replace);
    return 0;
}
