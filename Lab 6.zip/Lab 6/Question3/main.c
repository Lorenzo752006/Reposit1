#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char title[40];
    char author[40];
    float price;
    long offset;
} Book;

void create_indexes(FILE *fp, Book *index, int *count) {
    *count = 0;
    long offset = 0;
    while (fread(&index[*count], sizeof(Book), 1, fp)) {
        index[*count].offset = offset;
        (*count)++;
        offset += sizeof(Book);
    }
}

void display_books(FILE *fp, Book *index, int count, int order) {
    printf("\nBooks:\n");
    for (int i = 0; i < count; i++) {
        int idx = order ? count - 1 - i : i;
        fseek(fp, index[idx].offset, SEEK_SET);
        Book book;
        fread(&book, sizeof(Book), 1, fp);
        printf("Title: %s, Author: %s, Price: $%.2f\n", book.title, book.author, book.price);
    }
}

int main() {
    FILE *fp = fopen("book.dat", "rb");
    if (!fp) {
        perror("Unable to open file");
        return 1;
    }

    Book index[100];
    int count = 0;
    create_indexes(fp, index, &count);

    display_books(fp, index, count, 0); // Ascending
    display_books(fp, index, count, 1); // Descending

    fclose(fp);
    return 0;
}
