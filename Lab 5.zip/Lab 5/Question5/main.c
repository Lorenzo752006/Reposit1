#include <stdio.h>

#define SIZE 101

int main() {
    double f[SIZE][SIZE][SIZE];

    for (int x = 0; x < SIZE; x++) {
        for (int y = 0; y < SIZE; y++) {
            for (int z = 0; z < SIZE; z++) {
                f[x][y][z] = x + 6 * y + 7.2 * z;
            }
        }
    }

    printf("f(2,3,4) = %.2f\n", f[2][3][4]);
    return 0;
}
