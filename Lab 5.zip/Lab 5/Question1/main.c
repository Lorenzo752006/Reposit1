#include <stdio.h>
#include <stdlib.h>

int* Copy(int const *arr, int size) {
    int* copyArr = (int*)malloc(size * sizeof(int));
    if (copyArr == NULL) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    for (int i = 0; i < size; i++) {
        copyArr[i] = arr[i];
    }
    return copyArr;
}

int main(void) {
    int arr[10] = {69, 7, 23, 6, 5, 42, 56, 12, 88, 91};
    int size = sizeof(arr) / sizeof(arr[0]);

    int* copiedArray = Copy(arr, size);
    if (copiedArray == NULL) {
        return 1;
    }

    printf("Copied Array:\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", copiedArray[i]);
    }
    printf("\n");

    free(copiedArray);
    return 0;
}
