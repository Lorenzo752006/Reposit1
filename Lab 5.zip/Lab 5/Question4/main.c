#include <stdio.h>

int sum(int *start, int *end) {
    int total = 0;
    while (start < end)
        total += *start++;
    return total;
}

int main() {
    int arr[] = {1, 2, 3, 4, 5};
    int result = sum(arr, arr + 5);
    printf("Sum: %d\n", result);
    return 0;
}
