#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_EMPLOYEES 5

typedef struct {
    char name[30];
    char surname[30];
    int id;
    float salary;
} Employee;

int compareByID(const void *a, const void *b) {
    return ((Employee *)a)->id - ((Employee *)b)->id;
}

int compareBySurname(const void *a, const void *b) {
    return strcmp(((Employee *)a)->surname, ((Employee *)b)->surname);
}

int main() {
    Employee employees[MAX_EMPLOYEES] = {
        {"John", "Doe", 102, 5000},
        {"Alice", "Smith", 101, 5500},
        {"Bob", "Johnson", 103, 6000},
        {"Charlie", "Brown", 105, 4800},
        {"Eve", "Williams", 104, 5100}
    };

    qsort(employees, MAX_EMPLOYEES, sizeof(Employee), compareByID);
    printf("\nSorted by ID:\n");
    for (int i = 0; i < MAX_EMPLOYEES; i++)
        printf("%d: %s %s, $%.2f\n", employees[i].id, employees[i].name, employees[i].surname, employees[i].salary);

    qsort(employees, MAX_EMPLOYEES, sizeof(Employee), compareBySurname);
    printf("\nSorted by Surname:\n");
    for (int i = 0; i < MAX_EMPLOYEES; i++)
        printf("%s %s (ID: %d), $%.2f\n", employees[i].name, employees[i].surname, employees[i].id, employees[i].salary);

    return 0;
}
