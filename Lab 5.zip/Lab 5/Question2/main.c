#include <stdio.h>

void copy_array(int *source, int *destination, int size) {
    for (int i = 0; i < size; i++) {
        destination[i] = source[i];
    }
}

int main() {
    int source[] = {1, 2, 3, 4, 5};
    int destination[5];

    copy_array(source, destination, 10);  // Oversized size
    printf("Copied array (possible buffer overflow issue!): ");
    for (int i = 0; i < 10; i++) {  // Accessing beyond allocated space
        printf("%d ", destination[i]);
    }
    printf("\n");

    return 0;
}
