#include <stdio.h>
#include <stdlib.h>
#include <string.h>

union ipv4 {
    unsigned char octets[4];
    unsigned int address;
};

int main() {
    union ipv4 ip;
    char input[16];

    printf("Enter IPv4 address (e.g., 192.168.1.1): ");
    scanf("%15s", input);

    sscanf(input, "%hhu.%hhu.%hhu.%hhu", &ip.octets[3], &ip.octets[2], &ip.octets[1], &ip.octets[0]);

    printf("Octet form: %u.%u.%u.%u\n", ip.octets[3], ip.octets[2], ip.octets[1], ip.octets[0]);
    printf("Hexadecimal: 0x%08X\n", ip.address);

    return 0;
}
