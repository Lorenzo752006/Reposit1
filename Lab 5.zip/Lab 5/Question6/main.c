#include <stdio.h>
#include <string.h>

#define MAX_STRINGS 5
#define MAX_LENGTH 100

int main() {
    char strings[MAX_STRINGS][MAX_LENGTH];
    char suffix[MAX_LENGTH];

    printf("Enter %d strings:\n", MAX_STRINGS);
    for (int i = 0; i < MAX_STRINGS; i++) {
        fgets(strings[i], MAX_LENGTH, stdin);
        strings[i][strcspn(strings[i], "\n")] = '\0';
    }

    printf("Enter suffix to append: ");
    fgets(suffix, MAX_LENGTH, stdin);
    suffix[strcspn(suffix, "\n")] = '\0';

    printf("Modified strings:\n");
    for (int i = 0; i < MAX_STRINGS; i++) {
        printf("%s%s\n", strings[i], suffix);
    }

    return 0;
}
